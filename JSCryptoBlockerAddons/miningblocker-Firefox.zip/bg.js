var globCheck;

var scriptsRemove = 0;
var isHive = false;

var searchListURLS = ['CoinHive','Coin-Hive',
    'jsecoin',
    'mataharirama',
    'minecrunch',
    'coin-have',
    'hashforcash',
    'coinerra',
    'reasedoper',
    'minemytraffic',
    'lmodr',
    'cryptoloot',
    'crypto-loot',
    'listat',
    'monero.worker',
    'scrypt.worker',
    'scrypt.asm',
    'neoscrypt.asm',
    'gus.host',
    'xbasfbno',
    'azvjudwr',
    'jyhfuqoh',
    'miner.pr0gramm',
    'jroqvbvw',
    'projectpoi',
    'kdowqlpt',
    'ppoi',
    'minemytraffic',
    'inwemo',
    'minero',
    'coinblind',
    'coinnebula',
    'coinlab',
    'cloudcoins',
    'deepc',
    'monerominer',
    'gridcash',
    'monad',
    'ad-miner',
    'socketminer',
    'cloudcoins',
    'webmine',
    'mineralt',
    'authedmine',
    'hashunited',
    'webminepool',
    'monerise',
    'coinpirate',
    'crypto-webminer',
    'c-hive',
    'moneta',
    'monkeyminer',
    'cryptonight'];

var searchListContent = ['miner',
    "\x6d\x69\x6e\x65\x72",
    "\x4d\x69\x6e\x65\x72",
    'CoinHive',
    "\x63\x6f\x69\x6e\x68\x69\x76\x65",
    'Coin-Hive',
    'Coin-Have',
    'hashforcash',
    'coinerra',
    'jsecoin',
    'mataharirama',
    'minecrunch',
    'reasedoper',
    'minemytraffic',
    'cryptoloot',
    'crypto-loot',
    'inwemo',
    'minero',
    'CoinBlind',
    'coinnebula',
    'minemytraffic',
    'cryptonight',
    'coinlab',
    'cloudcoins',
    'monerominer',
    'deepMiner',
    'gridcash',
    'monad',
    'ad-miner',
    'socketminer',
    'cloudcoins',
    'webmine',
    'mineralt',
    'authedmine',
    'webminepool',
    'monerise',
    'coinpirate',
    'crypto-webminer',
    'c-hive',
    'moneta',
    'CRLT.Anonymous',
    'hashunited'];


//main
function checkPageForMiningScrpits() {
    try {
        if(globCheck == null){
            browser.runtime.sendMessage({whatsTheKonst: "giveMe"}, function (response) {
                globCheck = response.globCheck;
                startTheCheck();
            });
        } else{
            startTheCheck();
        }
    } catch (e) {}
}

function startTheCheck(){
    if (globCheck !== 2) {
        updateIcon(4);
        deleteElementsBeforeLoading();
        recheck();
    } else {
        updateIcon(0);
    }
}

//block mining scripts and empty scripts
function deleteElementsBeforeLoading() {
    var mutatObs = new MutationObserver(process);
    mutatObs.observe(document, {subtree:true, childList:true});
    document.addEventListener('DOMContentLoaded', function () {
        mutatObs.disconnect();
    }, false);

    function process(mutats) {
        for (var i = 0; i < mutats.length; i++) {
            var nodes = mutats[i].addedNodes;
            for (var o = 0; o < nodes.length; o++) {
                var no = nodes[o];

                if (no.nodeType !== 1)
                    continue;

                searchListURLS.forEach(function (searchFor){
                    if (no.matches('script') && no.src.toUpperCase().includes(searchFor.toUpperCase())) {
                        no.src = "";
                        scriptsRemove++;
                        console.log("Found mining: "+ searchFor);
                    }else if(no.matches('script')){

                        var currentContext = no.innerText.toString();
                        currentContext = currentContext.replace(/(\r\n|\n|\r)/gm, "");
                        currentContext = currentContext.replace(/ /g, "");

                        if (currentContext.toUpperCase().includes(searchFor.toUpperCase()+".")) {
                            no.innerText = "";
                            scriptsRemove++;
                            console.log("Found mining: "+ searchFor);
                        } else if (currentContext.toUpperCase().includes(searchFor.toUpperCase()+"/")) {
                            no.innerText = "";
                            scriptsRemove++;
                            console.log("Found mining: "+ searchFor);
                        } else if (currentContext.toUpperCase().includes(searchFor.toUpperCase()+"(")) {
                            no.innerText = "";
                            scriptsRemove++;
                            console.log("Found mining: "+ searchFor);
                        } else if (currentContext.toUpperCase().includes(searchFor.toUpperCase()+"-")) {
                            no.innerText = "";
                            scriptsRemove++;
                            console.log("Found mining: "+ searchFor);
                        }else if (currentContext.toUpperCase().includes(searchFor.toUpperCase()+"[")) {
                            no.innerText = "";
                            scriptsRemove++;
                            console.log("Found mining: "+ searchFor);
                        }
                    }
                });
            }
        }
    }
}

//add recheck function
function recheck(){
    document.addEventListener('DOMContentLoaded', function () {
        checkForRunningMiner();
    }, false);
}

//try to kill running Miners (jic)
function checkForRunningMiner() {
    var scripts = document.getElementsByTagName("script");
    var sl = scripts.length;

    for (var i = 0; i < sl; i++) {
        try {
            var currentContext = scripts[i].textContent;
            currentContext = currentContext.replace(/(\r\n|\n|\r)/gm, "");
            currentContext = currentContext.replace(/ /g, "");

            searchListContent.forEach(function (searchFor) {

                if (currentContext.toUpperCase().includes(searchFor.toUpperCase() + ".")) {
                    killMiner(currentContext, searchFor);
                    console.log("Found mining: " + searchFor);
                } else if (currentContext.toUpperCase().includes(searchFor.toUpperCase() + "/")) {
                    killMiner(currentContext, searchFor);
                    console.log("Found mining: " + searchFor);
                } else if (currentContext.toUpperCase().includes(searchFor.toUpperCase() + "(")) {
                    killMiner(currentContext, searchFor);
                    console.log("Found mining: " + searchFor);
                } else if (currentContext.toUpperCase().includes(searchFor.toUpperCase() + "-")) {
                    killMiner(currentContext, searchFor);
                    console.log("Found mining: " + searchFor);
                } else if (currentContext.toUpperCase().includes(searchFor.toUpperCase() + "[")) {
                    killMiner(currentContext, searchFor);
                    console.log("Found mining: " + searchFor);
                }
            });
        } catch (e) {
        }
    }

    if (scriptsRemove === 0 && !isHive) {
        updateIcon(0);
    }else{
        updateIcon(2);
    }

}


//call Stop
function killMiner(currentContext, searchFor) {
    try{
        var cleanScriptSplit = currentContext.split("new" + searchFor);

        var whereIsTheName = cleanScriptSplit[0];

        var startLoc = whereIsTheName.lastIndexOf("var") + 3;
        var endLoc = whereIsTheName.lastIndexOf("=");

        var varName = whereIsTheName.substring(startLoc, endLoc);

        if (globCheck !== 2) {
            isHive = true;
            if (!varName.includes(";")) {
                console.log("Found mining: " + searchFor);
                addScript("try{if(window." + varName + ".isRunning){window." + varName + ".stop();}}catch(e){}");
                addScript("try{window." + varName + " = null;}catch(e){}");
                updateIcon(2);
            }
        }
    }catch(e){}
}

//execute stop call
function addScript(callStopper) {
    var script = document.createElement("script");
    var scriptContent = document.createTextNode(callStopper);
    script.appendChild(scriptContent);
    document.head.appendChild(script);
}

//change browser icon
function updateIcon(state) {
    if (globCheck === 1) {
        if (state === 0) {
            browser.runtime.sendMessage({newIconPath: 0});
        } else if (state === 1) {
            browser.runtime.sendMessage({newIconPath: 1});
        }  else if (state === 2) {
            browser.runtime.sendMessage({newIconPath: 2});
        } else if (state === 4) {
            browser.runtime.sendMessage({newIconPath: 4});
        }
    } else {
        browser.runtime.sendMessage({newIconPath: 3});
    }
}

browser.runtime.onMessage.addListener(
    function(request, sender, sendResponse) {
        globCheck = request.checkKonst;
        sendResponse({gotIt: 1});
    }
);


checkPageForMiningScrpits();
